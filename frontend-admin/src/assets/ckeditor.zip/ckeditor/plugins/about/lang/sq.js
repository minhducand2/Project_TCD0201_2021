﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'sq', {
	copy: 'Të drejtat  e autorit &copy; $1. Të gjitha të drejtat e rezervuara.',
	dlgTitle: 'Rreth CKEditor 4',
	moreInfo: 'Për informacione rreth licencave shih faqen tonë:'
} );
